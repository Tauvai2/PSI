#include "Duomenys.h"
//------------------------------------------------------------
/* Duomenu mazgo klase
@class Mazgas Mazgas.h */
class Mazgas
{
private:
	Duomenys D;
	Mazgas *pirmyn;   // tolimesnio elemento adresas   
    Mazgas *atgal;    // pries esancio elemento adresas
public:
	 /** Konstruktorius 
  @param Duom � duomenu dalis 
  @param pirm � adresas pirmyn 
  @param atga � adresas atgal */ 
	Mazgas(const Duomenys & Duom = Duomenys(), Mazgas * const pirm = NULL, Mazgas * const atga = NULL) :
          D(Duom), pirmyn (pirm), atgal (atga) 
  {  } 
	
/** Priskiria duomenu dali */ 
	void DetiDuom(const Duomenys & Duom){ D = Duom; }
/** Priskiria rodyklei pirmyn reiksme */   
	void DetiPirmyn(Mazgas *pirm)       { pirmyn = pirm;} 
/** Priskiria rodyklei atgal reiksme */   
	void DetiAtgal(Mazgas *atga)      { atgal = atga;} 
/** Grazina Komandos tipo objekta */ 
	Duomenys Imti() const{ return D; }
/** Grazina adresa pirmyn */ 
	Mazgas *Pirmyn(){ return pirmyn; } 
/** Grazina adresa pirmyn */ 
	const Mazgas *Pirmyn() const{ return pirmyn; } 
/** Grazina adresa atgal */ 
	Mazgas *Atgal(){ return atgal; }  
/** Grazina adresa atgal */ 
	const Mazgas *Atgal() const{ return atgal; } 
	Mazgas & operator =(const Mazgas & xx);
	bool operator >(const Mazgas & xx) const;
};
