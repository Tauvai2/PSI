﻿#pragma once

#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>

#include "Sarasas.h"
#include "Duomenys.h"

namespace L3Deim {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	// Konvertuoja eilute s (String ^) i os (string)
	void StringTostring(String ^ s, string & os)
	{
		using namespace Runtime::InteropServices;
		const char* chars = (const char *)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
		os = chars;
		Marshal::FreeHGlobal(IntPtr((void*)chars));
	}

	/** Is fv nuskaito studentu duomenis i sarasa
	@param fv – duomenu failo vardas
	@param s – klases Sarasas kintamasis naudojamas formuojant sarasa */
	void SkaitytiStud(const string fv, Sarasas & s)
	{
		Duomenys d;
		ifstream fd(fv);
		string modulis, pavarde, vardas, grupe;
		int kreditai = 0;
		while (!fd.eof()) {
			fd >> modulis;
			fd >> pavarde;
			fd >> vardas;
			fd >> grupe;
			d.Deti(modulis, pavarde, vardas, grupe, kreditai);
			s.Sukurti(d);
			fd.ignore();
		}
		fd.close();
	}
	//------------------------------------------------------------
	/** Is fv nuskaito moduliu duomenis i sarasa
	@param fv – duomenų failo vardas
	@param s – klases Sarasas kintamasis naudojamas formuojant sarasa */
	void SkaitytiMod(const string fv, Sarasas & s)
	{
		Duomenys d;
		ifstream fd(fv);
		string modulis, pavarde, vardas, grupe = "";
		int kreditai = 0;
		while (!fd.eof()) {
			fd >> modulis;
			fd >> pavarde;
			fd >> vardas;
			fd >> kreditai;
			d.Deti(modulis, pavarde, vardas, grupe, kreditai);
			s.Sukurti(d);
		}
		fd.close();
	}
	//------------------------------------------------------------
	/** Papildo fv faila lentele saraso objektu reiksmemis
	@param fv – duomenu failo vardas
	@param s – klases Sarasas kintamasis naudojamas formuojant sarasa
	@param pavadinimas – lenteles pavadinimas */
	void Rasyti(const string fv, Sarasas & s, string pavadinimas)
	{
		ofstream fr(fv, ios::app);
		fr << pavadinimas << endl;
		fr << "+-----------------------------------------------------------------------------+" << endl;
		fr << "|           Modulis    |     Pavarde    |     Vardas     |   Grupe / Kreditai | " << endl;
		fr << "+-----------------------------------------------------------------------------+" << endl;
		for (s.PradetiPr(); s.Yra(); s.EitiPirmyn()) {
			Duomenys st = s.Imti();
			fr << left << "| " << setw(20) << st.ImtiModuli() << " | " << setw(14)
				<< st.ImtiPavarde() << " | " << setw(14) << st.ImtiVarda() << " | ";

			if (st.ImtiGrupe() == "")
				fr << setw(18) << st.ImtiKreditus() << " |" << endl;
			else
				fr << setw(18) << st.ImtiGrupe() << " |" << endl;
		}
		fr << "+-----------------------------------------------------------------------------+" << endl;
		fr.close();
	}
	//------------------------------------------------------------
	/** Papildo fv faila lentele saraso objektu reiksmemis
	@param fv – duomenu failo vardas
	@param s – klases Sarasas kintamasis naudojamas formuojant sarasa
	@param pavadinimas – lenteles pavadinimas */
	void RasytiDuom(const string fv, Sarasas & s, string pavadinimas)
	{
		ofstream fr(fv, ios::app);
		fr << pavadinimas << endl;
		fr << "+----------------------+" << endl;
		for (s.PradetiPr(); s.Yra(); s.EitiPirmyn()) {
			Duomenys duom = s.Imti();
			fr << left << "| " << setw(20) << duom.ImtiModuli() << " |" << endl;
		}
		fr << "+----------------------+" << endl;
		fr.close();
	}
	//------------------------------------------------------------
	/** Isrenka pateikto studento modulius i rezultatu sarasa
	@param stud – klases Sarasas kintamasis naudojamas formuojant sarasa
	@param modul – formuojamas naujas sarasas
	@param pavVar – studento pavarde + vardas */
	void Sudaryti(Sarasas & stud, Sarasas & modul, string pavVar)
	{
		for (stud.PradetiPr(); stud.Yra(); stud.EitiPirmyn())
		{
			if (stud.Imti().ImtiPavVar() == pavVar)
			{
				modul.Sukurti(stud.Imti().ImtiModuli());
			}
		}
	}
	//------------------------------------------------------------
	/** Isrenka pasirinktus modulius i rezultatu sarasa
	@param stud –  klases Sarasas kintamasis naudojamas formuojant sarasa
	@param moduliai – formuojamas naujas sarasas */
	void Pasirinkti(Sarasas & stud, Sarasas & moduliai)
	{
		for (stud.PradetiPr(); stud.Yra(); stud.EitiPirmyn())
		{
			if (!moduliai.Yra(stud.Imti().ImtiModuli()))
				moduliai.Sukurti(stud.Imti().ImtiModuli());
		}
	}
	/*
	for (stud.PraDeti(); stud.Baigti(); stud.Eiti())
	{
	if (!moduliai.Yra(stud.Imti().ImtiModuli()))
	moduliai.SukurtiT(stud.Imti().ImtiModuli());
	}
	*/
	//------------------------------------------------------------
	/** Sudaro sarasa moduliu, kuriu niekas nepasirinko
	@param stud – klases Sarasas kintamasis naudojamas formuojant sarasa
	@param modul – modulio duomenu sarasas
	@param moduliai – formuojamas naujas sarasas */
	void Nepasirinkti(Sarasas & stud, Sarasas  & modul, Sarasas  & moduliai)
	{
		bool pasirinko = false;
		for (modul.PradetiPr(); modul.Yra(); modul.EitiPirmyn())
		{
			pasirinko = false;
			for (stud.PradetiPr(); stud.Yra(); stud.EitiPirmyn())
			{
				if (stud.Imti().ImtiModuli() == modul.Imti().ImtiModuli())
				{
					pasirinko = true;
					break;
				}
			}

			if (!pasirinko)
				moduliai.Sukurti(modul.Imti().ImtiModuli());
		}
	}
	//------------------------------------------------------------
	/** Atrenka studenta, turinti daugiausia moduliu
	@param stud – klases Sarasas kintamasis naudojamas formuojant sarasa
	@param modul – modulio duomenu sarasas
	@return maxstud - daugiausiai moduliu turintis destytojas */
	string KurisDaugiausiai(Sarasas  & stud)
	{
		int max = 0;
		string maxstud = "";
		Sarasas modul;
		for (stud.PradetiPr(); stud.Yra(); stud.EitiPirmyn()){
			modul.Sukurti(stud.Imti());
		}

		for (modul.PradetiPr(); modul.Yra(); modul.EitiPirmyn())
		{
			int kiek = 0;
			for (stud.PradetiPr(); stud.Yra(); stud.EitiPirmyn())
			{
				if (modul.Imti().ImtiPavVar() == stud.Imti().ImtiPavVar())
				{
					kiek++;
				}
			}
			if (kiek > max)
			{
				max = kiek;
				maxstud = modul.Imti().ImtiPavVar();
			}
		}
		return maxstud;
	}

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		Sarasas *St;
		Sarasas  *D;
		Sarasas  *P, *Np, *S;
		String ^CDfv11, ^CDfv22;
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  skaitytiToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  rasytiToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  baigtiToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  atvertiFaila1ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  atvertiFaila2ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  pagalbaToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  saugotiToolStripMenuItem;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::RichTextBox^  richTextBox1;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog1;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog2;
	private: System::Windows::Forms::SaveFileDialog^  saveFileDialog1;

			 System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
			 /// <summary>
			 /// Required method for Designer support - do not modify
			 /// the contents of this method with the code editor.
			 /// </summary>
			 void InitializeComponent(void)
			 {
				 this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
				 this->skaitytiToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				 this->rasytiToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				 this->baigtiToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				 this->atvertiFaila1ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				 this->atvertiFaila2ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				 this->pagalbaToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				 this->saugotiToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				 this->textBox1 = (gcnew System::Windows::Forms::TextBox());
				 this->label1 = (gcnew System::Windows::Forms::Label());
				 this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
				 this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
				 this->openFileDialog2 = (gcnew System::Windows::Forms::OpenFileDialog());
				 this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
				 this->menuStrip1->SuspendLayout();
				 this->SuspendLayout();
				 // 
				 // menuStrip1
				 // 
				 this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(7) {
					 this->skaitytiToolStripMenuItem,
						 this->rasytiToolStripMenuItem, this->baigtiToolStripMenuItem, this->atvertiFaila1ToolStripMenuItem, this->atvertiFaila2ToolStripMenuItem,
						 this->pagalbaToolStripMenuItem, this->saugotiToolStripMenuItem
				 });
				 this->menuStrip1->Location = System::Drawing::Point(0, 0);
				 this->menuStrip1->Name = L"menuStrip1";
				 this->menuStrip1->Size = System::Drawing::Size(649, 24);
				 this->menuStrip1->TabIndex = 0;
				 this->menuStrip1->Text = L"menuStrip1";
				 // 
				 // skaitytiToolStripMenuItem
				 // 
				 this->skaitytiToolStripMenuItem->Name = L"skaitytiToolStripMenuItem";
				 this->skaitytiToolStripMenuItem->Size = System::Drawing::Size(57, 20);
				 this->skaitytiToolStripMenuItem->Text = L"Skaityti";
				 this->skaitytiToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::skaitytiToolStripMenuItem_Click);
				 // 
				 // rasytiToolStripMenuItem
				 // 
				 this->rasytiToolStripMenuItem->Name = L"rasytiToolStripMenuItem";
				 this->rasytiToolStripMenuItem->Size = System::Drawing::Size(50, 20);
				 this->rasytiToolStripMenuItem->Text = L"Rasyti";
				 this->rasytiToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::rasytiToolStripMenuItem_Click);
				 // 
				 // baigtiToolStripMenuItem
				 // 
				 this->baigtiToolStripMenuItem->Name = L"baigtiToolStripMenuItem";
				 this->baigtiToolStripMenuItem->Size = System::Drawing::Size(49, 20);
				 this->baigtiToolStripMenuItem->Text = L"Baigti";
				 this->baigtiToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::baigtiToolStripMenuItem_Click);
				 // 
				 // atvertiFaila1ToolStripMenuItem
				 // 
				 this->atvertiFaila1ToolStripMenuItem->Name = L"atvertiFaila1ToolStripMenuItem";
				 this->atvertiFaila1ToolStripMenuItem->Size = System::Drawing::Size(91, 20);
				 this->atvertiFaila1ToolStripMenuItem->Text = L"Atverti faila 1 ";
				 this->atvertiFaila1ToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::atvertiFaila1ToolStripMenuItem_Click);
				 // 
				 // atvertiFaila2ToolStripMenuItem
				 // 
				 this->atvertiFaila2ToolStripMenuItem->Name = L"atvertiFaila2ToolStripMenuItem";
				 this->atvertiFaila2ToolStripMenuItem->Size = System::Drawing::Size(88, 20);
				 this->atvertiFaila2ToolStripMenuItem->Text = L"Atverti faila 2";
				 this->atvertiFaila2ToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::atvertiFaila2ToolStripMenuItem_Click);
				 // 
				 // pagalbaToolStripMenuItem
				 // 
				 this->pagalbaToolStripMenuItem->Name = L"pagalbaToolStripMenuItem";
				 this->pagalbaToolStripMenuItem->Size = System::Drawing::Size(61, 20);
				 this->pagalbaToolStripMenuItem->Text = L"Pagalba";
				 this->pagalbaToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::pagalbaToolStripMenuItem_Click);
				 // 
				 // saugotiToolStripMenuItem
				 // 
				 this->saugotiToolStripMenuItem->Name = L"saugotiToolStripMenuItem";
				 this->saugotiToolStripMenuItem->Size = System::Drawing::Size(59, 20);
				 this->saugotiToolStripMenuItem->Text = L"Saugoti";
				 this->saugotiToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::saugotiToolStripMenuItem_Click);
				 // 
				 // textBox1
				 // 
				 this->textBox1->Location = System::Drawing::Point(12, 63);
				 this->textBox1->Name = L"textBox1";
				 this->textBox1->Size = System::Drawing::Size(169, 20);
				 this->textBox1->TabIndex = 1;
				 // 
				 // label1
				 // 
				 this->label1->AutoSize = true;
				 this->label1->Location = System::Drawing::Point(12, 37);
				 this->label1->Name = L"label1";
				 this->label1->Size = System::Drawing::Size(126, 13);
				 this->label1->TabIndex = 2;
				 this->label1->Text = L"Iveskite Pavarde ir Varda";
				 // 
				 // richTextBox1
				 // 
				 this->richTextBox1->Font = (gcnew System::Drawing::Font(L"Courier New", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					 static_cast<System::Byte>(0)));
				 this->richTextBox1->Location = System::Drawing::Point(12, 89);
				 this->richTextBox1->Name = L"richTextBox1";
				 this->richTextBox1->Size = System::Drawing::Size(615, 219);
				 this->richTextBox1->TabIndex = 3;
				 this->richTextBox1->Text = L"";
				 // 
				 // openFileDialog1
				 // 
				 this->openFileDialog1->FileName = L"openFileDialog1";
				 // 
				 // openFileDialog2
				 // 
				 this->openFileDialog2->FileName = L"openFileDialog2";
				 // 
				 // MyForm
				 // 
				 this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
				 this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
				 this->ClientSize = System::Drawing::Size(649, 320);
				 this->Controls->Add(this->richTextBox1);
				 this->Controls->Add(this->label1);
				 this->Controls->Add(this->textBox1);
				 this->Controls->Add(this->menuStrip1);
				 this->MainMenuStrip = this->menuStrip1;
				 this->Name = L"MyForm";
				 this->Text = L"MyForm";
				 this->menuStrip1->ResumeLayout(false);
				 this->menuStrip1->PerformLayout();
				 this->ResumeLayout(false);
				 this->PerformLayout();

			 }
#pragma endregion
	private: System::Void skaitytiToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		rasytiToolStripMenuItem->Enabled = true;
		St = new Sarasas; //studentu duomenys
		D = new Sarasas; //destytoju duomenys
		P = new Sarasas; //pasirinkti studentu moduliai
		Np = new Sarasas; //nepasirinkti studentu moduliai
		S = new Sarasas; //vieno studento duomenys

	}
	private: System::Void rasytiToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		richTextBox1->LoadFile(CDfv22, RichTextBoxStreamType::PlainText);
		delete St;
		delete D;
		delete P;
		delete Np;
		delete S;
	}
	private: System::Void atvertiFaila2ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		// Inicializuoja openFileDialog vaizda
		openFileDialog2->DefaultExt = ".txt";
		openFileDialog2->Filter = "TXT failai|*.txt";
		// Patikrina, ar vartotojas pasirinko faila is OpenFileDialog?
		if (openFileDialog2->ShowDialog() == System::Windows::Forms::DialogResult::OK
			&& openFileDialog2->FileName->Length > 0) {
			// Isveda failo turini i RichTextBox
			String^ dfv;
			// duomenu failo vardas (String ^)
			dfv = openFileDialog2->FileName;
			richTextBox1->LoadFile(dfv, RichTextBoxStreamType::PlainText);
			// Duomenu failo vardas dfv (Sting ^) konvertuojamas i dfvs (string)
			string dfvs;
			// duomenu failo vardas (string)
			StringTostring(dfv, dfvs);

			SkaitytiMod(dfvs, *D);

		}
	}
	private: System::Void atvertiFaila1ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		// Inicializuoja openFileDialog vaizda
		openFileDialog1->DefaultExt = ".txt";
		openFileDialog1->Filter = "TXT failai|*.txt";
		// Patikrina, ar vartotojas pasirinko faila is OpenFileDialog?
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK
			&& openFileDialog1->FileName->Length > 0) {
			// Isveda failo turini i RichTextBox
			String^ dfv;
			// duomenu failo vardas (String ^)
			dfv = openFileDialog1->FileName;
			richTextBox1->LoadFile(dfv, RichTextBoxStreamType::PlainText);
			// Duomenu failo vardas dfv (Sting ^) konvertuojamas i dfvs (string)
			string dfvs;
			// duomenu failo vardas (string)
			StringTostring(dfv, dfvs);


			SkaitytiStud(dfvs, *St);
		}
	}
	private: System::Void pagalbaToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		MessageBox::Show("Sveiki, noredami gauti rezultatus, pirmiausia spauskite"
			"meniu punkta skaityti, tuomet irasykite norima Pavarde Varda, tuomet atidarykite reikiamus duomenu failus,"
			"spauskite saugoti, pasirinkite ar parasykite .txt faila ,o galiausiai spauskite rasyti."
			"Studentai renkasi modulius.Studentas gali rinktis keleta moduliu.Uz"
			"modulius yra atsakingi destytojai.Suformuokite pasirinktu moduliu sarasa.Sudarykite atskira"
			"moduliu, kuriu studentai nepasirinko, sarasa.Suraskite, kuris studentas pasirinko daugiausiai moduliu."
			"Duomenys:"
			"Tekstiniame faile U12a.txt duota informacija apie studentu pasirenkamus modulius : modulio"
			"pavadinimas, studento pavarde, vardas, grupe."
			"Tekstiniame faile U12b.txt duota informacija apie modulius : modulio pavadinimas, atsakingo"
			"destytojo pavarde, vardas, kreditu kiekis."
			"Spausdinamas sarasas turi buti surikiuotas abeceles tvarka.Sudarykite nurodyto studento(ivedamas"
			" klaviatura) pasirinktu moduliu sarasa.");
	}
	private: System::Void saugotiToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		// Inicializuoja saveFileDialog vaizda
		saveFileDialog1->DefaultExt = ".txt";
		saveFileDialog1->Filter = "TXT failai|*.txt";
		// Patikrina, ar vartotojas pasirinko faila is SaveFileDialog?
		if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK
			&&       saveFileDialog1->FileName->Length > 0) {
			String^ rfv;
			// rezultatu failo vardas (String ^)
			rfv = saveFileDialog1->FileName;
			// Rezultatu failo vardas rfv (Sting ^) konvertuojamas i rfvs (string)
			string rfvs;
			// rezultatu failo vardas (string)
			StringTostring(rfv, rfvs);
			// Sukuriamas tuscias rezultatu failas
			ofstream fr(rfvs.c_str());
			fr.close();
			// Atliekami veiksmai su failu rfvs (pvz.: rezultatu spausdinimas)
			// ...
			string pavvar;
			Rasyti(rfvs.c_str(), *St, "Studentu pasirinkti moduliai:");
			Rasyti(rfvs.c_str(), *D, "Informacija apie modulius:");

			Pasirinkti(*St, *P);
			Nepasirinkti(*St, *D, *Np);

			St->Rikiuoti();
			Np->Rikiuoti();

			RasytiDuom(rfvs.c_str(), *P, "Pasirinktu moduliu sarasas:");
			RasytiDuom(rfvs.c_str(), *Np, "Nepasirinktu moduliu sarasas:");

			String ^ h = (textBox1->Text);
			StringTostring(h, pavvar);

			Sudaryti(*St, *S, pavvar);

			S->Rikiuoti();
			RasytiDuom(rfvs.c_str(), *S, "Studento " + pavvar + " moduliu sarasas:");

			fr.open(rfvs.c_str(), ios::app);
			fr << "Daugiausia moduliu turi studentas - " + KurisDaugiausiai(*St) << endl;
			fr.close();
			CDfv22 = gcnew String(rfvs.c_str());
		}
	}
	private: System::Void baigtiToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		Close();
	}
};
	}