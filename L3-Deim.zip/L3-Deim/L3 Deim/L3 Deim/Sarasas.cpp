#include "Sarasas.h"
//------------------------------------------------------------ 
/** Kopijos konstruktorius */ 
Sarasas::Sarasas(const Sarasas & kitas)
{ 
  Mazgas *dn;   
  pr = pb = NULL; 
  for (Mazgas *d = kitas.pr; d != NULL; d = d->Pirmyn()) 
  { 
    dn = new Mazgas (d->Imti(), NULL, pb);     
	if (!pr) 
      pr = pb = dn; 
 	else 
     pb->DetiPirmyn(dn);     
	pb = dn; 
  } 
} 
//------------------------------------------------------------ 
/* Priskyrimo operatorius */
Sarasas & Sarasas::operator = (const Sarasas & kitas)
{
	if (this == &kitas){ //Ar tai yra taspats objektas??
		return *this;
	}
	else 
	{
	Naikinti();
	Mazgas *dn;   
	pr = pb = NULL; 
	for (Mazgas *d = kitas.pr; d != NULL; d = d->Pirmyn()) 
		{ 
		dn = new Mazgas (d->Imti(), NULL, pb);     
		if (!pr) 
		  pr = pb = dn; 
 		else 
		 pb->DetiPirmyn(dn);     
		pb = dn; 
		} 
	}
	return *this;
}
//------------------------------------------------------------ 
// Destruktorius  
Sarasas::~Sarasas()
{ 
  Naikinti(); 
} 
//------------------------------------------------------------ 
/** Sunaikina s�ra�� */ 
void Sarasas::Naikinti()
{ 
  Mazgas *naik;   
  while (pr != NULL)
  {     
	  naik = pr;     
	  pr = pr->Pirmyn();     
	  delete naik; 
  }   
  pb = NULL;   
  eina = NULL; 
} 
//------------------------------------------------------------ 
/** Sukuria nauj� s�ra�o element� 
  @param duomp � klas�s Darbininkas kintamasis */ 
void Sarasas::Sukurti(const Duomenys & duomp)
{ 
  if (pr == NULL) 
    pb = pr = new Mazgas(duomp);   
  else { 
    Mazgas *iterpt = new Mazgas(duomp, NULL, pb);     
	pb->DetiPirmyn(iterpt);     
	pb = iterpt; 
  } 
} 
//------------------------------------------------------------ 
void Sarasas::Rikiuoti()
{
	Mazgas *tmp = new Mazgas;
	for (Mazgas *sna = pr; sna != NULL; sna = sna->Pirmyn())
	{
		Mazgas *ats = sna;
		for (Mazgas *sb = sna->Pirmyn(); sb != NULL; sb = sb->Pirmyn())
			if (*ats > *sb)
				ats = sb;
		*tmp = *ats;
		*ats = *sna;
		*sna = *tmp;
	}
	delete tmp;
}
//----------------------------------------------------------
bool Sarasas::Yra(string ieskomasis)
{
	for (Mazgas *sna = pr; sna != NULL; sna = sna->Pirmyn())
	{
		if (sna->Imti() == ieskomasis)
			return true;
	}
	return false;
}