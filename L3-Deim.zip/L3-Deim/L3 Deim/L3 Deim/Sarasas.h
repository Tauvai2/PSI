#include <iomanip>
#include <string>
#include <fstream>
#include "Mazgas.h"
using namespace std;
//------------------------------------------------------------
//------------------------------------------------------------
/** Darbininku vienkryptis sarasas
@class Sarasas */
class Sarasas
{
private:
	Mazgas *pr, *pb, // sarasas pradzios ir pabaigos rodykles
		*eina; // sasajos rodykle
public:
	Sarasas() : pr(NULL), eina(NULL), pb(NULL)
    { } 
	Sarasas(const Sarasas & kitas);
	Sarasas & operator = (const Sarasas & kitas);
	~Sarasas();

	
	/** Nustato rodykle i saraso pradzia */     
	void PradetiPr() { eina = pr; }    
	/** Nustato rodykle i saraso pabaiga */     
	void PradetiPb() { eina = pb; }    
	/** Tikrina sasajos rodykle 
   @return gra�ina tiesa, jei rodyklr lygi Null*/     
	bool Baigti() const{ return eina == NULL; }  
	/** Tikrina sasajos rodykle 
   @return grazina tiesa, jei rodykle nelygi Null*/     
	bool Yra() const{ return eina != NULL; }  
	/** Grazina Komandos tipo objekta pagal sasajos rodykle */ 
	Duomenys Imti() const{ return eina->Imti(); }  
	/** Pastumia sasajos rodykle i prieki */ 
    void EitiPirmyn() { eina = eina->Pirmyn();}     
	/** Pastumia s�sajos rodykl� atgal */     
	void EitiAtgal() { eina = eina->Atgal(); }          
	void Sukurti(const Duomenys & duomp);
	void Naikinti();    
	void Rikiuoti();
	bool Yra(string ieskomasis);
};