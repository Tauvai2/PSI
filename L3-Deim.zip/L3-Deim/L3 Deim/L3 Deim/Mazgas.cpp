#include "Mazgas.h"
//------------------------------------------------------------ 
/** Uzklotas = operatorius */ 
Mazgas & Mazgas::operator =(const Mazgas & xx) 
{ 
  D = xx.D;   return *this; 
} 
//------------------------------------------------------------ 
bool Mazgas::operator >(const Mazgas & xx) const
{
	return (D > xx.D);
}