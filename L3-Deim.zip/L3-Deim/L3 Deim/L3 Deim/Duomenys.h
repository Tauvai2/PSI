#pragma once
#include <string>
using namespace std;

//------------------------------------------------------------
/** Destytoju / studentu duomenu saugojimo klase
@class Duomenys Duomenys.h */
class Duomenys {
private:
	string modPavadinimas; // modulio pavadinimas
	string pavarde; // pavarde
	string vardas; // vardas
	string grupe; // studento grupe
	int kreditai; // destytojo kreditai
public:
	/** konstruktorius su parametrais
	@param a � modulio pavadinimas
	@param b � pavarde
	@param c � vardas
	@param d � grupe
	@param kred � kreditai */
	Duomenys(string a = "", string b = "", string c = "", string d = "", int kred = 0) :
		modPavadinimas(a), pavarde(b), vardas(c), grupe(d), kreditai(kred) {}
	~Duomenys(){}
	/** Idedamos objekto reiksmes
	@param a � modulio pavadinimas
	@param b � pavarde
	@param c � vardas
	@param d � grupe
	@param kred � kreditai */
	void Deti(string a, string b, string c, string d, int kred) { modPavadinimas = a; pavarde = b; vardas = c; grupe = d; kreditai = kred; }
	string ImtiModuli() { return modPavadinimas; }
	string ImtiPavarde() { return pavarde; }
	string ImtiVarda() { return vardas; }
	string ImtiGrupe() { return grupe; }
	int ImtiKreditus() { return kreditai; }
	/** Grazina pavarde ir varda viename string */
	string ImtiPavVar() { return pavarde + " " + vardas; }
	/** Operatorius dvieju elementu palyginimui pagal pavarde ir varda
	@param kitas � objektas palyginimui */
	bool operator > (const Duomenys & kitas) const {
		return pavarde > kitas.pavarde || pavarde == kitas.pavarde && vardas > kitas.vardas;
	}
	bool operator == (const Duomenys & kitas) const {
		return modPavadinimas == kitas.modPavadinimas;
	}
};
//------------------------------------------------------------
