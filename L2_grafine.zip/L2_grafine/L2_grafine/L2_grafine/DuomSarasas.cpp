#include "DuomSarasas.h"
/** Sukuriamas saraso elementas ir prijungiamas prie saraso pradzios
@param naujas � naujo elemento reiksme */
void DuomSarasas::DetiDuomenisA(Duomenys naujas)
{
	DuomenysSar *dd = new DuomenysSar;
	dd->inf = naujas;
	dd->kitas = p;
	p = dd;
}

//------------------------------------------------------------
/** Sukuriamas saraso elementas ir prijungiamas prie saraso pabaigos
@param naujas � naujo elemento reiksme */
void DuomSarasas::DetiDuomenisT(Duomenys naujas)
{
	DuomenysSar *dd = new DuomenysSar;
	dd->inf = naujas;
	dd->kitas = NULL;
	if (p) {
		g->kitas = dd;
		g = dd;
	}
	else {
		p = dd;
		g = dd;
	}
}
//------------------------------------------------------------
/** Sunaikinamas sarasas */
void DuomSarasas::Naikinti()
{
	while (p) {
		d = p;
		p = p->kitas;
		delete d;
	}
	g = d = p;
}

//------------------------------------------------------------
/** Rikiuojamas sarasas */
void DuomSarasas::Rikiuoti()
{
	if (p == NULL) return;
	bool keista = true;
	while (keista) {
		keista = false;
		DuomenysSar *pr = p;
		while (pr->kitas != NULL) {
			Duomenys da = pr->inf;
			Duomenys db = pr->kitas->inf;
			if (da > db) {
				pr->inf = db;
				pr->kitas->inf = da;
				keista = true;
			}
			pr = pr->kitas;
		}
	}
}