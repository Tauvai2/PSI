﻿#include "MyForm.h"

//------------------------------------------------------------
using namespace System;
using namespace System::Windows::Forms;
[STAThread]
int main(array<System::String ^> ^args)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	L2_grafine::MyForm form; // Eilutė, kuri gali būti koreguojama
	Application::Run(%form);
}
//------------------------------------------------------------