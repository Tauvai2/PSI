﻿#pragma once

#include <string>
#include "Duomenys.h"

using namespace std;

//------------------------------------------------------------
/** Vienkrypčio saraso elementas */
struct DuomenysSar {
	Duomenys inf; // informacine saraso dalis
	DuomenysSar *kitas; // rodykle i kita saraso elementa
};
//------------------------------------------------------------
/** Vienkryptis sarasas
@class DuomSarasas DuomSarasas.h */
class DuomSarasas {
private:
	DuomenysSar *p; // saraso pradzios rodykle
	DuomenysSar *d; // vidine darbine rodykle sasajos metodams
	DuomenysSar *g; // saraso pabaigos rodykle
public:
	/** Konstruktorius be parametru */
	DuomSarasas() : p(NULL), d(NULL), g(NULL) { }
	~DuomSarasas() { Naikinti(); }
	/** Sasajos rodyklei priskiriama saraso pradzia */
	void Pradzia() { d = p; }
	/** Sasajos rodyklei priskiriamas saraso sekancio elemesto adresas */
	void Kitas() { d = d->kitas; }
	/** Grazina true, jeigu sasajos rodykle netuscia */
	bool NePabaiga() { return d != NULL; }
	/** Grazina sasajos rodykles rodomo elemento reiksme*/
	Duomenys ImtiDuomenis() { return d->inf; }
	/** Deda duomenis atvirkstiniu metodu
	@param naujas - dedami duomenys **/
	void DetiDuomenisA(Duomenys naujas);
	/** Deda duomenis tiesioginiu metodu
	@param naujas - dedami duomenys **/
	void DetiDuomenisT(Duomenys naujas);
	// Duomenu manipuliavimo metodai
	void Naikinti();
	void Rikiuoti();
};