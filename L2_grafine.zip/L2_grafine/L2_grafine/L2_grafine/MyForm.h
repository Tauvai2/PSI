﻿#pragma once

#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>

#include "Sarasas.h"
#include "Duomenys.h"
#include "DuomSarasas.h"

using namespace std;

namespace L2_grafine {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	//-----------------------------------------------------------
	const string CDfv1 = "U12a.txt";
	const string CDfv2 = "U12b.txt";
	const string CRfv = "Rezultatai.txt";
	//------------------------------------------------------------

	void StringTostring(String ^ s, string & os)
	{
		using namespace Runtime::InteropServices;
		const char* chars = (const char *)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
		os = chars;
		Marshal::FreeHGlobal(IntPtr((void*)chars));
	}

	/** Is fv nuskaito studentu duomenis i sarasa
	@param fv – duomenu failo vardas
	@param s – duomenu SaraSo objekto adresas */
	void SkaitytiStud(const string fv, DuomSarasas & s)
	{
		Duomenys d;
		ifstream fd(fv);
		string modulis, pavarde, vardas, grupe;
		int kreditai = 0;
		while (!fd.eof()) {
			fd >> modulis;
			fd >> pavarde;
			fd >> vardas;
			fd >> grupe;
			d.Deti(modulis, pavarde, vardas, grupe, kreditai);
			s.DetiDuomenisA(d);
		}
		fd.close();
	}
	//------------------------------------------------------------
	/** Is fv nuskaito moduliu duomenis i sarasa
	@param fv – duomenų failo vardas
	@param s – duomenų saraso objekto adresas */
	void SkaitytiMod(const string fv, DuomSarasas & s)
	{
		Duomenys d;
		ifstream fd(fv);
		string modulis, pavarde, vardas, grupe = "";
		int kreditai = 0;
		while (!fd.eof()) {
			fd >> modulis;
			fd >> pavarde;
			fd >> vardas;
			fd >> kreditai;
			d.Deti(modulis, pavarde, vardas, grupe, kreditai);
			s.DetiDuomenisT(d);
		}
		fd.close();
	}
	//------------------------------------------------------------
	/** Papildo fv faila lentele saraso objektu reiksmemis
	@param fv – duomenu failo vardas
	@param s – duomenu saraso objekto adresas
	@param pavadinimas – lenteles pavadinimas */
	void Rasyti(const string fv, DuomSarasas & s, string pavadinimas)
	{
		ofstream fr(fv, ios::app);
		fr << pavadinimas << endl;
		fr << "+-----------------------------------------------------------------------------+" << endl;
		fr << "|           Modulis    |     Pavarde    |     Vardas     |   Grupe / Kreditai | " << endl;
		fr << "+-----------------------------------------------------------------------------+" << endl;
		for (s.Pradzia(); s.NePabaiga(); s.Kitas()) {
			Duomenys st = s.ImtiDuomenis();
			fr << left << "| " << setw(20) << st.ImtiModuli() << " | " << setw(14)
				<< st.ImtiPavarde() << " | " << setw(14) << st.ImtiVarda() << " | ";

			if (st.ImtiGrupe() == "")
				fr << setw(18) << st.ImtiKreditus() << " |" << endl;
			else
				fr << setw(18) << st.ImtiGrupe() << " |" << endl;
		}
		fr << "+-----------------------------------------------------------------------------+" << endl;
		fr.close();
	}
	//------------------------------------------------------------
	/** Papildo fv faila lentele saraso objektu reiksmemis
	@param fv – duomenu failo vardas
	@param s – rezultatu saraso objekto adresas
	@param pavadinimas – lenteles pavadinimas */
	void Rasyti(const string fv, Sarasas & s, string pavadinimas)
	{
		ofstream fr(fv, ios::app);
		fr << pavadinimas << endl;
		fr << "+----------------------+" << endl;
		for (s.Pradzia(); s.NePabaiga(); s.Kitas()) {
			string duom = s.ImtiDuomenis();
			fr << left << "| " << setw(20) << duom << " |" << endl;
		}
		fr << "+----------------------+" << endl;
		fr.close();
	}
	//------------------------------------------------------------
	/** Isrenka pateikto studento modulius i rezultatu sarasa
	@param stud – duomenu saraso objekto adresas
	@param modul – rezultatu saraso objekto adresas
	@param pavVar – studento pavarde + vardas */
	void Sudaryti(DuomSarasas & stud, Sarasas & modul, string pavVar)
	{
		for (stud.Pradzia(); stud.NePabaiga(); stud.Kitas())
		{
			if (stud.ImtiDuomenis().ImtiPavVar() == pavVar)
			{
				modul.DetiDuomenisT(stud.ImtiDuomenis().ImtiModuli());
			}
		}
	}
	//------------------------------------------------------------
	/** Isrenka pasirinktus modulius i rezultatu sarasa
	@param stud – duomenu saraso objekto adresas
	@param moduliai – rezultatu saraso objekto adresas */
	void Pasirinkti(DuomSarasas & stud, Sarasas & moduliai)
	{
		for (stud.Pradzia(); stud.NePabaiga(); stud.Kitas())
		{
			if (!moduliai.Yra(stud.ImtiDuomenis().ImtiModuli()))
				moduliai.DetiDuomenisT(stud.ImtiDuomenis().ImtiModuli());
		}
	}
	//------------------------------------------------------------
	/** Sudaro sarasa moduliu, kuriu niekas nepasirinko
	@param stud – duomenu saraso objekto adresas
	@param modul – duomenu saraso objekto adresas
	@param moduliai – rezultatu saraso objekto adresas */
	void Nepasirinkti(DuomSarasas & stud, DuomSarasas & modul, Sarasas & moduliai)
	{
		bool pasirinko = false;
		for (modul.Pradzia(); modul.NePabaiga(); modul.Kitas())
		{
			pasirinko = false;
			for (stud.Pradzia(); stud.NePabaiga(); stud.Kitas())
			{
				if (stud.ImtiDuomenis().ImtiModuli() == modul.ImtiDuomenis().ImtiModuli())
				{
					pasirinko = true;
					break;
				}
			}

			if (!pasirinko)
				moduliai.DetiDuomenisT(modul.ImtiDuomenis().ImtiModuli());
		}
	}
	//------------------------------------------------------------
	/** Atrenka studenta, turinti daugiausia moduliu
	@param stud – duomenu saraso objekto adresas
	@param modul – duomeny saraso objekto adresas
	@return maxstud - daugiausiai moduliu turintis destytojas */
	string KurisDaugiausiai(DuomSarasas & stud)
	{
		int kiek = 0;
		int max = -1;
		string maxstud;
		DuomSarasas modul;
		for (stud.Pradzia(); stud.NePabaiga(); stud.Kitas())
			modul.DetiDuomenisT(stud.ImtiDuomenis());

		for (modul.Pradzia(); modul.NePabaiga(); modul.Kitas())
		{
			for (stud.Pradzia(); stud.NePabaiga(); stud.Kitas())
			{
				if (stud.ImtiDuomenis().ImtiModuli() == modul.ImtiDuomenis().ImtiModuli())
				{
					kiek++;
				}
			}
			if (kiek > max)
			{
				max = kiek;
				maxstud = modul.ImtiDuomenis().ImtiPavVar();
			}
		}
		return maxstud;
	}
	//------------------------------------------------------------

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	protected:
	private: System::Windows::Forms::MenuStrip^  menuStrip2;
	private: System::Windows::Forms::ToolStripMenuItem^  failasToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  skaitytiToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  redaguotiToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  skaiciuotiToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  baigtiToolStripMenuItem;
	private: System::Windows::Forms::RichTextBox^  richTextBox1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::Button^  button1;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->menuStrip2 = (gcnew System::Windows::Forms::MenuStrip());
			this->failasToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->skaitytiToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->redaguotiToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->skaiciuotiToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->baigtiToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->menuStrip2->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->Location = System::Drawing::Point(0, 24);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(706, 24);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// menuStrip2
			// 
			this->menuStrip2->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->failasToolStripMenuItem, 
				this->redaguotiToolStripMenuItem, this->baigtiToolStripMenuItem});
			this->menuStrip2->Location = System::Drawing::Point(0, 0);
			this->menuStrip2->Name = L"menuStrip2";
			this->menuStrip2->Size = System::Drawing::Size(706, 24);
			this->menuStrip2->TabIndex = 1;
			this->menuStrip2->Text = L"menuStrip2";
			// 
			// failasToolStripMenuItem
			// 
			this->failasToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->skaitytiToolStripMenuItem});
			this->failasToolStripMenuItem->Name = L"failasToolStripMenuItem";
			this->failasToolStripMenuItem->Size = System::Drawing::Size(48, 20);
			this->failasToolStripMenuItem->Text = L"Failas";
			this->failasToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::failasToolStripMenuItem_Click);
			// 
			// skaitytiToolStripMenuItem
			// 
			this->skaitytiToolStripMenuItem->Name = L"skaitytiToolStripMenuItem";
			this->skaitytiToolStripMenuItem->Size = System::Drawing::Size(152, 22);
			this->skaitytiToolStripMenuItem->Text = L"Skaityti";
			this->skaitytiToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::skaitytiToolStripMenuItem_Click);
			// 
			// redaguotiToolStripMenuItem
			// 
			this->redaguotiToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->skaiciuotiToolStripMenuItem});
			this->redaguotiToolStripMenuItem->Name = L"redaguotiToolStripMenuItem";
			this->redaguotiToolStripMenuItem->Size = System::Drawing::Size(73, 20);
			this->redaguotiToolStripMenuItem->Text = L"Redaguoti";
			// 
			// skaiciuotiToolStripMenuItem
			// 
			this->skaiciuotiToolStripMenuItem->Name = L"skaiciuotiToolStripMenuItem";
			this->skaiciuotiToolStripMenuItem->Size = System::Drawing::Size(125, 22);
			this->skaiciuotiToolStripMenuItem->Text = L"Skaiciuoti";
			this->skaiciuotiToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::skaiciuotiToolStripMenuItem_Click);
			// 
			// baigtiToolStripMenuItem
			// 
			this->baigtiToolStripMenuItem->Name = L"baigtiToolStripMenuItem";
			this->baigtiToolStripMenuItem->Size = System::Drawing::Size(49, 20);
			this->baigtiToolStripMenuItem->Text = L"Baigti";
			this->baigtiToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::baigtiToolStripMenuItem_Click);
			// 
			// richTextBox1
			// 
			this->richTextBox1->Font = (gcnew System::Drawing::Font(L"Courier New", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox1->Location = System::Drawing::Point(12, 114);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(625, 226);
			this->richTextBox1->TabIndex = 2;
			this->richTextBox1->Text = L"";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(12, 37);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(233, 20);
			this->textBox1->TabIndex = 3;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(12, 74);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(233, 20);
			this->textBox2->TabIndex = 4;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(495, 70);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 5;
			this->button1->Text = L"button1";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::skaitytiToolStripMenuItem_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(706, 352);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->menuStrip1);
			this->Controls->Add(this->menuStrip2);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->menuStrip2->ResumeLayout(false);
			this->menuStrip2->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void skaitytiToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		DuomSarasas studentai,		// studentu duomenys
			moduliai;		// destytoju duomenys
		Sarasas		pasirinkti,		// moduliu sarasas
			nepasirinkti,	// destytoju sarasas
			studento;
		ofstream fr(CRfv); fr.close();

		SkaitytiStud(CDfv1, studentai);
		SkaitytiMod(CDfv2, moduliai);

		richTextBox1->Clear();
		Rasyti(CRfv, studentai, "Studentu pasirinkti moduliai:");

		Rasyti(CRfv, moduliai, "Informacija apie modulius:");

		Pasirinkti(studentai, pasirinkti);
		Nepasirinkti(studentai, moduliai, nepasirinkti);

		Rasyti(CRfv, pasirinkti, "Pasirinktu moduliu sarasas:");
		Rasyti(CRfv, nepasirinkti, "Nepasirinktu moduliu sarasas:");

		fr.open(CRfv, ios::app);
		fr << "Daugiausia moduliu turi studentas - " + KurisDaugiausiai(studentai) << endl;
		fr.close();
		richTextBox1->LoadFile("Rezultatai.txt", RichTextBoxStreamType::PlainText);
		textBox1->Text = "Iveskite studento Pavarde ir Varda";
	}
private: System::Void baigtiToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
	Close();
}
private: System::Void richTextBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void skaiciuotiToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
	DuomSarasas studentai,		// studentu duomenys
		moduliai;		// destytoju duomenys
	Sarasas		pasirinkti,		// moduliu sarasas
		nepasirinkti,	// destytoju sarasas
		studento;
	ofstream fr(CRfv); fr.close();

	richTextBox1->Clear();
	SkaitytiStud(CDfv1, studentai);
	SkaitytiMod(CDfv2, moduliai);

	string pavvar;
	Rasyti(CRfv, studentai, "Studentu pasirinkti moduliai:");
	Rasyti(CRfv, moduliai, "Informacija apie modulius:");

	Pasirinkti(studentai, pasirinkti);
	Nepasirinkti(studentai, moduliai, nepasirinkti);

	pasirinkti.Rikiuoti();
	nepasirinkti.Rikiuoti();

	Rasyti(CRfv, pasirinkti, "Pasirinktu moduliu sarasas:");
	Rasyti(CRfv, nepasirinkti, "Nepasirinktu moduliu sarasas:");

	String ^ h = (textBox2->Text);
	StringTostring(h, pavvar);
	String^ str2 = gcnew String(pavvar.c_str());

	Sudaryti(studentai, studento, pavvar);

	studento.Rikiuoti();
	Rasyti(CRfv, studento, "Studento " + pavvar + " moduliu sarasas:");

	fr.open(CRfv, ios::app);
	fr << "Daugiausia moduliu turi studentas - " + KurisDaugiausiai(studentai) << endl;
	fr.close();
	richTextBox1->LoadFile("Rezultatai.txt", RichTextBoxStreamType::PlainText);
}
private: System::Void failasToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
