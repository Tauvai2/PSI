#pragma once

#include <string>
using namespace std;
//------------------------------------------------------------
/** Vienkrypcio saraso elementas */
struct Duom {
	string inf;			// informacine saraso dalis
	Duom *kitas; // rodykle i kita saraso elementa
};
//------------------------------------------------------------
/** Vienkryptis sarasas
@class Sarasas Sarasas.h */
class Sarasas {
private:
	Duom *p;		// saraso pradzios rodykle
	Duom *d;		// vidine darbine rodykle sasajos metodams
	Duom *g;		// saraso pabaigos rodykl�
	Duom *pries;	// saraso rodykle esanti pries darbine 
public:
	/** Konstruktorius be parametru */
	Sarasas() : p(NULL), d(NULL), g(NULL) { }
	~Sarasas() { Naikinti(); }
	// Sasajos metodai
	/** Sasajos rodyklei priskiriama saraso pradzia */
	void Pradzia() { d = pries = p; }
	/** Sasajos rodyklei priskiriamas saraso sekancio elemesto adresas */
	void Kitas();
	/** Grazina true, jeigu s�sajos rodykle netuscia */
	bool NePabaiga() { return d != NULL; }
	/** Grazina sasajos rodykles rodomo elemento reiksme*/
	string ImtiDuomenis() { return d->inf; }
	/** Deda duomenis atvirkstiniu metodu
	@param naujas - dedami duomenys **/
	void DetiDuomenisA(string naujas);
	/** Deda duomenis tiesioginiu metodu
	@param naujas - dedami duomenys **/
	void DetiDuomenisT(string naujas);

	// Duomenu manipuliavimo metodai
	void Naikinti();
	void Salinti();
	void Rikiuoti();
	bool Yra(string ieskomasis);

};