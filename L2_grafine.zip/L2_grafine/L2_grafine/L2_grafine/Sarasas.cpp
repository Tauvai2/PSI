#include "Sarasas.h"
/** Sukuriamas saraso elementas ir prijungiamas prie saraso pradzios
@param naujas � naujo elemento reiksme */
void Sarasas::DetiDuomenisA(string naujas)
{
	Duom *dd = new Duom;
	dd->inf = naujas;
	dd->kitas = p;
	p = dd;
}
//------------------------------------------------------------
/** Sukuriamas saraso elementas ir prijungiamas prie saraso pabaigos
@param naujas � naujo elemento reiksme */
void Sarasas::DetiDuomenisT(string naujas)
{
	Duom *dd = new Duom;
	dd->inf = naujas;
	dd->kitas = NULL;
	if (p) {
		g->kitas = dd;
		g = dd;
	}
	else {
		p = dd;
		g = dd;
	}
}
//------------------------------------------------------------
/** Sunaikinamas sarasas */
void Sarasas::Naikinti()
{
	while (p) {
		d = p;
		p = p->kitas;
		delete d;
	}
	g = d = p;
}
//------------------------------------------------------------
/** Rikiuojamas sarasas */
void Sarasas::Rikiuoti()
{
	if (p == NULL) return;
	bool keista = true;
	while (keista) {
		keista = false;
		Duom *pr = p;
		while (pr->kitas != NULL) {
			string da = pr->inf;
			string db = pr->kitas->inf;
			if (da > db) {
				pr->inf = db;
				pr->kitas->inf = da;
				keista = true;
				db = da;
			}
			pr = pr->kitas;
		}
	}
}
//------------------------------------------------------------
/** Salinamas saraso elementas */
void Sarasas::Salinti()
{
	Duom *s = d->kitas;
	if (s != NULL)
		*d = *s;
	else
	{
		pries->kitas = NULL;
		d = NULL;
	}
	delete s;
}
//------------------------------------------------------------
/** Tikrinama ar sarase yra ieskoma informacija
@param ieskomasis - ieskoma informacija */
bool Sarasas::Yra(string ieskomasis)
{
	for (Pradzia(); NePabaiga(); Kitas())
	{
		if (d->inf == ieskomasis)
			return true;
	}
	return false;
}

/** Sasajos rodyklei priskiriamas saraso sekancio elemesto adresas */
void Sarasas::Kitas() {
	if (d != NULL)
	{
		pries = d;
		d = d->kitas;
	}
}